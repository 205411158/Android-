package com.example.perbaikanuts.ui.dashboard


import android.content.Context

class TableClass(context: Context?) {
    val mContext : Context? = context;

    var no: Int? = 1;
    var description: String? = null;
    var amount: Double? = 0.0;
    var dosen: String? =null;

    var headerNo : String? = null;
    var headerDesc : String? = null;
    var headerAmount : String? = null;
    var headerDosen : String? = null;

    fun addHeader(headerNo : String, headerDesc: String, headerAmount : String, headerDosen : String) : TableClass{
        val data = TableClass(mContext);
        data.headerNo = headerNo;
        data.headerDesc = headerDesc;
        data.headerAmount = headerAmount;
        data.headerDosen = headerDosen;
        return data;
    }

    fun addData(no : Int, description: String, amount : Double, dosen : String) : TableClass{
        val data = TableClass(mContext);
        data.no = no;
        data.description = description;
        data.amount = amount;
        data.dosen = dosen;
        return data;
    }
}