package com.example.perbaikanuts.ui.dashboard

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.perbaikanuts.R


class DashboardFragment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_dashboard)

        val matkul = TableClass(this);
        val data = ArrayList<TableClass>();
        data.clear();
        data.add(matkul.addHeader("No", "Mata Kuliah", "SKS", headerDosen = "Dosen"));
        data.add(matkul.addData(1, "Pemrograman berbasis Mobile", 3.0, "L.N.HarnaningrumS.Si, M.T."));
        data.add(matkul.addData(2, "Teknologi Mobile", 2.0,"Yosef MKA,S.T., M.Kom."));
        data.add(matkul.addData(3, "Praktikum Teknologi Cloud", 1.0,"Dr.Bambang P.D.P.S.E, Akt., S.Kom, MMSI."));
        data.add(matkul.addData(4, "Teknologi Cloud", 2.0, "Dr.Bambang P.D.P.S.E, Akt., S.Kom, MMSI."));
        data.add(matkul.addData(5, "Data Lake", 3.0,"Sri R,S.Si., M.Kom."));
        data.add(matkul.addData(6, "Bahasa Inggris 3", 1.0,"Tlau SS, S.S., M.Hum."));
        data.add(matkul.addData(7, "Proyek Pengembangan Aplikasi Web", 3.0,"Badiyanto, S.Kom., M.Kom."));
        data.add(matkul.addData(8, "Praktikum Infrastruktur Big Data", 1.0, "Robby CB, S.Kom., M.Kom."));
        data.add(matkul.addData(9, "Infrastruktur Big Data", 3.0,"Robby CB, S.Kom., M.Kom."));
        data.add(matkul.addData(10, "Teknologi Cloud Lanjut", 2.0,"M. Agung N, S.Kom., M.Kom."));
        data.add(matkul.addData(11, "Praktek Kerja Lapangan", 2.0,"Dini FS, ST., MT."));
       // TableAdapter(this, data).also{ adapter -> listMatkul.adapter = adapter }


    }
}
