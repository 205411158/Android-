package com.example.perbaikanuts.ui.dashboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import com.example.perbaikanuts.R


class TableAdapter(context: Context, data: ArrayList<TableClass>) :  ArrayAdapter<TableClass>(context, -1, data) {
    private val mContext: Context;
    private val dataSet: ArrayList<TableClass>;
    private val headerColor = Color.parseColor("#0062cc");

    init {
        mContext = context;
        dataSet = data;
    }

    class ViewHolder(row : View?) {
        var layout : LinearLayout? = null;
        var txtNo : TextView? = null;
        var txtDescription: TextView? = null;
        var txtAmount: TextView? = null;
        var txtDosen: TextView? = null;

        init {
            layout = row?.findViewById(R.id.listLayout) as LinearLayout;
            txtNo = row?.findViewById(R.id.txtNo) as TextView;
            txtDescription = row?.findViewById(R.id.txtDescription) as TextView;
            txtAmount = row?.findViewById(R.id.txtSks) as TextView;
            txtDosen = row?.findViewById(R.id.txtDosen) as TextView
        }
    }

    override fun getViewTypeCount(): Int {
        return super.getCount()
    }

    override fun getItemViewType(position: Int): Int {
        return position;
    }

    private var lastPosition = -1
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val model: TableClass? = getItem(position);
        val viewHolder : ViewHolder;
        val view : View;

        if (convertView == null) {
            val inflater = mContext?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater;
            view = inflater.inflate(R.layout.layout_table_three, parent, false);
            viewHolder = ViewHolder(view);
            view.tag = viewHolder;
        }else{
            view = convertView;
            viewHolder = view.tag as ViewHolder;
            viewHolder.txtNo?.text = "";
            viewHolder.txtAmount?.text = "";
            viewHolder.txtDescription?.text = "";
            viewHolder.txtDosen?.text ="";
        }

        lastPosition = position

        if(model?.headerNo !=null && model?.headerDesc !=null && model?.headerAmount !=null){
            viewHolder.txtNo?.text = model?.headerNo.toString();
            viewHolder.txtDescription?.text = model?.headerDesc.toString();
            viewHolder.txtAmount?.text = model?.headerAmount.toString();
            viewHolder.txtDosen?.text = model?.headerDosen.toString();
            viewHolder.layout?.setBackgroundColor(headerColor);
            viewHolder.txtNo?.setTypeface(null, Typeface.BOLD);
            viewHolder.txtDescription?.setTypeface(null, Typeface.BOLD);
            viewHolder.txtAmount?.setTypeface(null, Typeface.BOLD);
            viewHolder.txtDosen?.setTypeface(null, Typeface.BOLD);
            viewHolder.txtNo?.setTextColor(Color.WHITE);
            viewHolder.txtDescription?.setTextColor(Color.WHITE);
            viewHolder.txtAmount?.setTextColor(Color.WHITE);
            viewHolder.txtDosen?.setTextColor(Color.WHITE);
        }else{
            viewHolder.txtNo?.text = model?.no.toString();
            viewHolder.txtDescription?.text = model?.description;
            viewHolder.txtAmount?.text = (String.format("%,.0f",model?.amount));
            viewHolder.txtDosen?.text = model?.dosen;
            viewHolder.layout?.setBackgroundColor(Color.WHITE);
            viewHolder.txtNo?.setTypeface(null, Typeface.NORMAL);
            viewHolder.txtDescription?.setTypeface(null, Typeface.NORMAL);
            viewHolder.txtAmount?.setTypeface(null, Typeface.NORMAL);
            viewHolder.txtDosen?.setTypeface(null,Typeface.NORMAL)
            viewHolder.txtNo?.setTextColor(Color.BLACK);
            viewHolder.txtDescription?.setTextColor(Color.BLACK);
            viewHolder.txtAmount?.setTextColor(Color.BLACK);
            viewHolder.txtDosen?.setTextColor(Color.BLACK)
        }


        return view as View;
    }
}